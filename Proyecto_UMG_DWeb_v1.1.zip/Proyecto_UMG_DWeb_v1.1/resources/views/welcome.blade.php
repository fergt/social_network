@extends('layouts.app')


@section('content')

</html>

    <Header class="container-fluid">
			<div class="row" style="height: 680px; background-color:#04a4ac">
				<div class="col-12 align-self-center text-center">
					<img src="{{asset('images/image1.png')}}" class="img-fluid" alt="">
					<h1>Bienvenido a Social Network</h1>
					<hr>
					<p> Conectate con tus amigos, familiares y tu crush</p>
				</div>			
			</div>
	</Header>
    <Footer class="container-fluid">
		<div class="row justify-content-center" style="background-color: #1a252f;">
			<div class="col-12 p-3 text-center">
				<p> Copyright © Social Network 2020
			</div> 
		</div>
	</Footer>
    </body>
</html>



@endsection




