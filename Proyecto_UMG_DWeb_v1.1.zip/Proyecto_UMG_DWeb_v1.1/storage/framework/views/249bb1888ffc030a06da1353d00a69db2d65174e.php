<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">

            <?php if(session('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('message')); ?>

                </div>
             <?php endif; ?>            

                <div class="card">

                    
                    <div class="main_image">
                        <div class="card-body">
                            <img src="<?php echo e(route('image.get',['filename' => $image->image_path])); ?>" alt="" class="col-md-12">
                            <br>
                            <br>
                            <div class="col-md-12">
                                <div class="row">
                                    <div class="col-md-11" align="right">
                                        <span style="color:#A0ADC2;">Fecha Publicación de Post. <br> <?php echo e($image->created_at); ?></span>
                                        <br>
                                        <span style="color:#A0ADC2;">publicado por. <br><?php echo e($image->user->name.' '.$image->user->apellido); ?></span>
                                        <br>
                                    </div>
                                </div>
                                
                                    <p style="color:#949393; font-size: 14px;">Información de Post. <br> <?php echo e($image->description); ?></p>

                                        
                                   
                                    
                                    <?php if(Auth::user()->id == $image->user->id): ?>
                                    
                                    <div align="col-md-12">
                                        <div class="row"> 
                                            <div class="col-md-11" align="right">
                                                
                                            <a href="#" class="btn btn-sm btn-info float-right far fa-edit fa-2x"> </a> 
                                        
                                            
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-sm btn-danger far fa-trash-alt fa-2x"  data-toggle="modal" data-target="#exampleModal"> </button>
                                            </div>
                                                

                                        </div>
                                    </div>
                                    
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    
                                                    <h5 class="modal-title" id="exampleModalLabel">¿Seguro que deseas borrarla?</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                
                                                <div class="modal-body">
                                                    
                                                    Si eliminas esta imagen nunca podras recuperarla
                                                </div>
                                                <div class="modal-footer">
                                                    
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                        
                                                        
                                                    <a href="<?php echo e(action('ImagenController@destroy',['id'=>$image->id_imagen])); ?>" class="btn btn-danger float-right">Borrar definitivamente</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <?php endif; ?>
                                    <br>
                                </div>
                            </div>  
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/Publicaciones/detalle.blade.php ENDPATH**/ ?>