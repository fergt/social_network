<div class="col-md-12">
    <?php if(Auth::user()->image): ?>
        <img src="<?php echo e(route('user.image',['filename' => Auth::user()->image])); ?>" alt="" class="col-md-12 rounded-radius" >
    <?php else: ?>
        <?php
            echo "Agrega un Avatar a tu perfil!"
        ?>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/includes/usrimagen.blade.php ENDPATH**/ ?>