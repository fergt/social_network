<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row justify-content-center ">
        <div class="col-md-8" >
                <div class="card text-center">
                    <div class="card-header"><?php echo e(__('Datos de Perfil')); ?></div>
                </div>
                <br>
                <div class="row">
                        <div class="col-xs-12 col-sm-6 text-center" style="width: 18rem;">
                            
                               <?php if( empty ($user->image)): ?>
                                    <img width="59" height="35" style="max-width:100%;width:auto;height:auto;" src="<?php echo e(asset('images/default-avatar.png')); ?>" alt="Image Not Available" class="card-img-top" >
                                <?php else: ?>
                                    <img src="<?php echo e(route('user.image',['filename' => $user->image ])); ?>" class="card-img-top" width="59" height="35"  alt="Avater Usuario" style="max-width:100%;width:auto;height:auto;" >
                                <?php endif; ?>

                        </div>
                        <div class="col-xs-12 col-sm-4 text-center ">
                            <h3 style="color:black; ">Hola! soy, <br> <?php echo e($user->name); ?>  <?php echo e($user->apellido); ?> </h3>
                            <p class="card-text" style="color:black;"><?php echo e($user->email); ?></p>
                            <p class="card-text" style="color:black;"><?php echo e($user->descripcion); ?></p>
                        </div>
                        <br>
                </div>
                <br>
                <div class="card-footer center">
                    <small class="text-muted">Ultima Acualización: <?php echo e($user->updated_at); ?></small>
                </div>
                <br>
                <?php if($errors->any()): ?>
                  <div class="alert alert-danger">
                    <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <li><?php echo e($error); ?></li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>



      <?php endif; ?>
                <div>
                    

                        <?php if(Auth::user()->id == $user->id): ?>
                            <div class="card">
                                <div class="card text-center">
                                    <div class="card-header">Nuevo Post</div>
                                    <div class="card-body">
                                    <form method="POST" action="<?php echo e(action('ImagenController@store')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                            <input name="id_user" id="id_user" type="hidden" value="<?php echo e(Auth::user()->id); ?>">
                                            <div class="form-group row">
                                                
                                                <div class="col btn btn-info" id="btn_editar">
                                                    <input id="image" name="image_path" type="file" class="form-control <?php $__errorArgs = ['image_path'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                        <span class="fa fa-upload" id="upload-image"><small>   Cargar Imagen</small></span>
                                                    

                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="description" class="col-md-3 col-form-label text-md-right">Mi comentario</label>
                                                <div class="col">
                                                    <textarea id="description" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" ></textarea>
                                                     <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                </div>
                                            </div>
                                            <div class="form-group row mb-0">
                                                <div class="col">
                                                    <button type="submit" class="btn btn-primary far fa-plus-square fa-2x">
                                                        Postear!
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <br>

                        <div>
                            <div class="card text-center">
                                <div class="card-header"><?php echo e(__('Mis Posts')); ?></div>
                            <br>
                            </div>
                                <?php $__currentLoopData = $user->imagen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make('includes.imagen',['imagenes'=> $image], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                            
                </div>
        </div>
    </div>
</div>        

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/usuario/miperfil.blade.php ENDPATH**/ ?>