<?php $__env->startSection('content'); ?>

</html>

    <Header class="container-fluid">
			<div class="row" style="height: 680px; background-color:#04a4ac">
				<div class="col-12 align-self-center text-center">
					<img src="<?php echo e(asset('images/image1.png')); ?>" class="img-fluid" alt="">
					<h1>Bienvenido a Social Network</h1>
					<hr>
					<p> Conectate con tus amigos, familiares y tu crush</p>
				</div>			
			</div>
	</Header>
    <Footer class="container-fluid">
		<div class="row justify-content-center" style="background-color: #1a252f;">
			<div class="col-12 p-3 text-center">
				<p> Copyright © Social Network 2020
			</div> 
		</div>
	</Footer>
    </body>
</html>



<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/welcome.blade.php ENDPATH**/ ?>