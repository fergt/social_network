    <div class="card">
        <div class="main_image">
            <div class="card-body">
                <a href="<?php echo e(action('ImagenController@show',['id' => $image->id_imagen])); ?>"><img src="<?php echo e(route('image.get',['filename' => $image->image_path])); ?>" alt="" class="col-md-12"></a>
                <br>
                <br>
                <div class="col-md-12">
                    <p style="color:#949393; font-size: 14px;"> <?php echo e($image->description); ?></p>
                    <div class="col-md-12">
                        <p style="color:#949393; font-size: 14px;" class="float-right"><?php echo e($image->created_at); ?></p>
                    </div>
                    <div class="col-md-10">Publicado por:
                        <a href="<?php echo e(action('UsuariosController@profile',['id' => $image->fk_id_user])); ?>">  <?php echo e($image->user->name.' '.$image->user->apellido); ?> </a>
                    </div>
                    <br>
                </div>    
            </div>
        </div>    
    </div>
    <br><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/includes/imagen.blade.php ENDPATH**/ ?>