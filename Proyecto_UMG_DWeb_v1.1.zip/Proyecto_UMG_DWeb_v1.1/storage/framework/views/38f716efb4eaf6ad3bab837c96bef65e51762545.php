<?php $__env->startSection('content'); ?>

<main class="page-content">
     
      <div class="container">
        <div class="card-header text-center"><h2 style="color:black;"><?php echo e(__('Nuevas publicaciones')); ?></h2></div>
          <div class="row justify-content-center">
            <br>
            <br>

            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <br>

                        <?php if(session('message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('message')); ?>

                            </div>
                            <br>
                        <?php endif; ?>

                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('includes.imagen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <br>
                        <div class="card-footer justify-content-center"><?php echo e($images->links()); ?></div>
                        
                    </div>
                </div>
            </div>

          </div>
        </div>
</main>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Proyecto_UMG_DWeb\Proyecto_UMG_DWeb\resources\views/Publicaciones/publicaciones.blade.php ENDPATH**/ ?>